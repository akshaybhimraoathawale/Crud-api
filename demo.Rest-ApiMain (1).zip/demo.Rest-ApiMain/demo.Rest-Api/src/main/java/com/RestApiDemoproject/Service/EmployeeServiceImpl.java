package com.RestApiDemoproject.Service;

import java.util.List;

import com.RestApiDemoproject.Bean.Employee;

public interface EmployeeServiceImpl {

	public Employee addEmployee(Employee employee);


	List<Employee> getallEmployee();


	public Employee getaEmployeeByid(int id);


	public void deleteEmployeeByid(int id);





}
