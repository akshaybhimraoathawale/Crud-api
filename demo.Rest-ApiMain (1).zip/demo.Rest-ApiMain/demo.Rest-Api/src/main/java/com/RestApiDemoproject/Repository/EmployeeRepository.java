package com.RestApiDemoproject.Repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.RestApiDemoproject.Bean.Employee;
import com.fasterxml.jackson.core.sym.Name;

@Repository
public interface EmployeeRepository extends CrudRepository<Employee, Integer> {

}
