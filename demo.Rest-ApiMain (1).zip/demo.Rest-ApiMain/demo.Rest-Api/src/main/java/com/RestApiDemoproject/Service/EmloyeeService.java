package com.RestApiDemoproject.Service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.RestApiDemoproject.Bean.Employee;
import com.RestApiDemoproject.Repository.EmployeeRepository;

@Service
public class EmloyeeService implements EmployeeServiceImpl {
	@Autowired
	public EmployeeRepository employeeRepository;

	@Override
	public Employee addEmployee(Employee employee) {
		Employee employee2 = employeeRepository.save(employee);
		return employee2;

	}

	@Override
	public List<Employee> getallEmployee() {
		return 	(List<Employee>) employeeRepository.findAll();
	
	}

	@Override
	public Employee getaEmployeeByid(int id) {
		return employeeRepository.findById(id).get();
	}

	@Override
	public void deleteEmployeeByid(int id) {
		employeeRepository.deleteById(id );
	}

	

	
	

}
